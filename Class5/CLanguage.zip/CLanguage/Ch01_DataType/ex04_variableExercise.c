#include <stdio.h>

int main_ex04_variableExercise()
{
    int num1 = 10, num2 = 20, num3 = 30;

    printf("%d %d %d\n", num1, num2, num3);

    return 0;
}