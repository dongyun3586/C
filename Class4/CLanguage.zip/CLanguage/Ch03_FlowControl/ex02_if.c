//#include<stdio.h>
//
//int main_ex02_if() {
//
//	int n;
//
//	printf("���� �Է�: ");
//	scanf("%d", &n);
//
//	if (n < 0)
//		n = -n;
//
//	pritf("���밪 %d \n", n);
//
//	return 0;
//}