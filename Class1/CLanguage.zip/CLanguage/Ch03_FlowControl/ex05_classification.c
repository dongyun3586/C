// ���ںз� (ex05_classification)

#include<stdio.h>

int main() {

	char ch;
	scanf("%c", &ch);

	if (ch >= '0')
		printf("%d", ch);

	return 0;
}